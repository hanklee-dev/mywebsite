document.addEventListener('DOMContentLoaded', function() {
  const introVideo = document.getElementById('introVideo');
  const skipButton = document.getElementById('skipButton');
  const choiceButtons = document.getElementById('choiceButtons');
  const popup = document.getElementById('popup');
  const popupContent = document.querySelector('.popup-content');
  const phoneInput = document.getElementById('phone');
  const passwordInput = document.getElementById('password');
  const loginButton = document.getElementById('loginButton');
  const tutorialButton = document.getElementById('tutorialButton'); // 추가
  const tutorialPopup = document.getElementById('tutorialPopup'); // 추가

  introVideo.controls = false; // 제어 기능 숨김
  introVideo.addEventListener('timeupdate', function() {
      if (introVideo.currentTime >= 10) {
          choiceButtons.classList.remove('hidden');
      }
  });

  introVideo.addEventListener('ended', function() {
      choiceButtons.classList.remove('hidden');
  });

  phoneInput.addEventListener('input', function() {
      toggleLoginButton();
      if (phoneInput.value.length === 11) { // 수정된 부분
          passwordInput.focus();
      }
  });

  passwordInput.addEventListener('input', function() {
      toggleLoginButton();
  });

  function toggleLoginButton() {
      if (phoneInput.value && passwordInput.value) {
          loginButton.disabled = false;
      } else {
          loginButton.disabled = true;
      }
  }

  window.skipIntro = function() {
      introVideo.currentTime = introVideo.duration;
  }

  function showVideo(videoSrc, callback) {
      introVideo.classList.add('hidden');
      skipButton.classList.add('hidden');
      choiceButtons.classList.add('hidden');
      const videoElement = document.createElement('video');
      videoElement.classList.add('video');
      videoElement.controls = false; // 제어 기능 숨김
      videoElement.innerHTML = `<source src="${videoSrc}" type="video/mp4">Your browser does not support the video tag.`;
      document.querySelector('.container').appendChild(videoElement);
      videoElement.play();

      videoElement.addEventListener('ended', function() {
          videoElement.remove();
          if (callback) callback();
      });
  }

  window.showCheckChoice = function() {
      introVideo.pause();
      showVideo('checkchoice.mp4', function() {
          popup.classList.remove('hidden');
          popup.style.display = 'flex';
      });
  }

  window.showWithdrawChoice = function() {
      introVideo.pause();
      showVideo('withdraw.mp4', function() {
          popup.classList.remove('hidden');
          popup.style.display = 'flex';
      });
  }

  window.clearPassword = function() {
      passwordInput.value = '';
      toggleLoginButton();
  }

  window.hideInitialScreen = function() {
      document.querySelector('.initial-screen').classList.add('hidden');
      introVideo.play();
  }

  // 팝업 바깥을 클릭하면 팝업 닫기 및 원래 화면 복귀
  popup.addEventListener('click', function(event) {
      if (!popupContent.contains(event.target)) {
          popup.style.display = 'none';
          introVideo.classList.remove('hidden');
          skipButton.classList.remove('hidden');
          choiceButtons.classList.remove('hidden');
      }
  });

  // 백비트 이용이 처음이신가요? 버튼 클릭 시 튜토리얼 팝업 표시
  tutorialButton.addEventListener('click', function() {
      tutorialPopup.style.display = 'flex';
  });

  // 튜토리얼 팝업 바깥을 클릭하면 팝업 닫기
  tutorialPopup.addEventListener('click', function(event) {
      if (!tutorialPopup.querySelector('.popup-content').contains(event.target)) {
          tutorialPopup.style.display = 'none';
      }
  });
});
